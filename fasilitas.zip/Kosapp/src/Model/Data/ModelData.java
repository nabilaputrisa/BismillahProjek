
package Model.Data;
public class ModelData {
    private int IdData;

    public int getId() {
        return IdData;
    }

    public void setId(int id) {
        this.IdData = IdData;
    }
    private String namaAnak;
    private String noAnak;
    private int angkatan;
    private int noKamar;
    private String namaOrtu;
    private String noOrtu;
    private String asal;

    public String getNamaAnak() {
        return namaAnak;
    }

    public void setNamaAnak(String namaAnak) {
        this.namaAnak = namaAnak;
    }

    public String getNoAnak() {
        return noAnak;
    }

    public void setNoAnak(String noAnak) {
        this.noAnak = noAnak;
    }

    public int getAngkatan() {
        return angkatan;
    }

    public void setAngkatan(int angkatan) {
        this.angkatan = angkatan;
    }

    public int getNoKamar() {
        return noKamar;
    }

    public void setNoKamar(int noKamar) {
        this.noKamar = noKamar;
    }

    public String getNamaOrtu() {
        return namaOrtu;
    }

    public void setNamaOrtu(String namaOrtu) {
        this.namaOrtu = namaOrtu;
    }

    public String getNoOrtu() {
        return noOrtu;
    }

    public void setNoOrtu(String noOrtu) {
        this.noOrtu = noOrtu;
    }

    public String getAsal() {
        return asal;
    }

    public void setAsal(String asal) {
        this.asal = asal;
    }

   
    
    
}
